#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <handy.h>
#include <string.h>

#define INIT_DEFAULT 0
#define INIT_COSTOMIZE 1
#define INIT_FAULT 0x0000FFFF

//-----Object Operation-----//
int hgp_object_move(int type, void *ptr, double direct_angle, double distance);
int hgp_object_rotate(int type, void *ptr, double rotate_arc, int need_angle_input_1);
int hgp_object_zoom(int type, void *ptr, double zoom_rate, double zoom_center_x, double zoom_center_y);

//-----Object Struct-----//
typedef struct HGP_OBJECT_WINDOW_INFO
{
    int window_id;
    int layer_id;
    int object_pointer_id;
    int table_id;
} HGP_OBJECT_WINDOW_INFO;

typedef struct HGP_RECT
{
    HGP_OBJECT_WINDOW_INFO window_info;
    double x;
    double y;
    double width;
    double height;
    unsigned long shell_color;
    unsigned long fill_color;
    int fill_flag;
    double rotate_arc;
    int stroke_lenth;
} HGP_RECT;

typedef struct HGP_CIRCLE
{
    HGP_OBJECT_WINDOW_INFO window_info;
    double x;
    double y;
    double r;
    unsigned long shell_color;
    unsigned long fill_color;
    int fill_flag;
    int stroke_lenth;
} HGP_CIRCLE;

typedef struct HGP_ARC
{
    HGP_OBJECT_WINDOW_INFO window_info;
    double x;
    double y;
    double r;
    unsigned long shell_color;
    double arc_start;
    double arc_value;
} HGP_ARC;

typedef struct HGP_FAN
{
    HGP_OBJECT_WINDOW_INFO window_info;
    double x;
    double y;
    double r;
    unsigned long shell_color;
    unsigned long fill_color;
    int fill_flag;
    int stroke_lenth;
    double arc_start;
    double arc_value;
} HGP_FAN;

//-----Globle-----//
void breakpoint();
int breakpointcount;
#define HGP_DIRECT_LEFT 0
#define HGP_DIRECT_RIGHT M_PI
#define HGP_DIRECT_UP (M_PI * 0.5)
#define HGP_DIRECT_DOWN (M_PI * 1.5)

#define HGP_RECT_CONTAINER_SIZE 1024
#define HGP_CIRCLE_CONTAINER_SIZE 1024
#define HGP_ARC_CONTAINER_SIZE 1024
#define HGP_FAN_CONTAINER_SIZE 1024

#define HGP_OBJECT_RECT_FLAG 0
#define HGP_OBJECT_CIRCLE_FLAG 1
#define HGP_OBJECT_ARC_FLAG 2
#define HGP_OBJECT_FAN_FLAG 3

#define HGP_OBJECT_TOTAL_NUM HGP_RECT_CONTAINER_SIZE +       \
                                 HGP_CIRCLE_CONTAINER_SIZE + \
                                 HGP_ARC_CONTAINER_SIZE +    \
                                 HGP_FAN_CONTAINER_SIZE

int hgp_update();
//-----Window-----//
typedef struct HGP_OBJECT_LOG
{
    int type;
    int pointer;
} HGP_OBJECT_LOG;

typedef struct HGP_OBJECT_INFO
{
    HGP_RECT *RECT[HGP_RECT_CONTAINER_SIZE];
    HGP_CIRCLE *CIRCLE[HGP_CIRCLE_CONTAINER_SIZE];
    HGP_ARC *ARC[HGP_ARC_CONTAINER_SIZE];
    HGP_FAN *FAN[HGP_FAN_CONTAINER_SIZE];

    HGP_OBJECT_LOG *table[HGP_OBJECT_TOTAL_NUM];
} HGP_OBJECT_INFO;

typedef struct HGP_LAYER_INFO
{
    int lid[2];
    HGP_OBJECT_INFO Object;
} HGP_LAYER_INFO;

typedef struct HGP_WINDOW_INFO
{
    int wid;
    HGP_LAYER_INFO *Layer[HG_MAX_LAYERS];
} HGP_WINDOW_INFO;

HGP_WINDOW_INFO *HGP_WINDOW_CONTAINER[HG_MAX_WINDOWS];
int HGP_WINDOW_COUNTER;
int hgp_window_init(double x, double y);
int hgp_create_window(double x, double y);
int hgp_add_layer(int window);
void *hgp_add_object(int obj_type_flag, int window, int layer);
int hgp_delete_object(int obj_type_flag, void *object);
int hgp_delete_layer(int window, int layer);
int hgp_destroy_window(int window, int quit_flag);
int hgp_quit();
int hgp_killHG();
int hgp_update();
int layer_reverse_flag;
//-----Object Init-----//
HGP_RECT *hgp_rect_init(int window, int layer, double x, double y,
                        double width, double height,
                        unsigned long shell_color, unsigned long fill_color,
                        int fill_flag, double rotate_arc, int stroke_lenth);

HGP_CIRCLE *hgp_circle_init(int window, int layer,
                            double x, double y, double r,
                            unsigned long shell_color,
                            unsigned long fill_color,
                            int fill_flag, int stroke_lenth);

HGP_ARC *hgp_arc_init(int window, int layer,
                      double x, double y, double r,
                      unsigned long shell_color,
                      double arc_start, double arc_value);

HGP_FAN *hgp_fan_init(int window, int layer,
                      double x, double y, double r,
                      unsigned long shell_color,
                      unsigned long fill_color,
                      int fill_flag, int stroke_lenth,
                      double arc_start, double arc_value);
