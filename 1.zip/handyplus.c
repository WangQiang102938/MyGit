#include "handyplus.h"
//#include "handy.h"
#define HGP_THIS_WINDOW HGP_WINDOW_CONTAINER[window]
#define HGP_THIS_LAYER HGP_WINDOW_CONTAINER[window]->Layer[layer]
#define HGP_THIS_OBJECT HGP_WINDOW_CONTAINER[window]->Layer[layer]->Object
#define breakp breakpoint();

int hgp_window_init(double x, double y)
{
    for (int i = 0; i < HG_MAX_WINDOWS; i++)
    {
        HGP_WINDOW_CONTAINER[i] = NULL;
    }
    int wid = hgp_create_window(x, y);
    if (wid == -1)
    {
        printf("window init failed\n");
    }
    return wid;
}

int hgp_create_window(double x, double y)
{
    int window = -1;
    for (int i = 0; i < HG_MAX_WINDOWS; i++)
    {
        if (HGP_WINDOW_CONTAINER[i] == NULL)
        {
            window = i;
            break;
        }
    }
    breakp;
    if (window != -1)
    {
        HGP_THIS_WINDOW = ((HGP_WINDOW_INFO *)malloc(sizeof(HGP_WINDOW_INFO)));
        HGP_THIS_WINDOW->wid = HgOpen(x, y);
        for (int i = 0; i < HG_MAX_LAYERS; i++)
        {
            HGP_THIS_WINDOW->Layer[i] = NULL;
        }
        hgp_add_layer(window);
    }
    breakp;
    return window;
}

int hgp_add_layer(int window) //TODO:obj init
{
    int layer = -1;
    for (int i = 0; i < HG_MAX_LAYERS; i++)
    {
        if (HGP_THIS_WINDOW->Layer[i] == NULL)
        {
            layer = i;
            break;
        }
    }
    if (layer != -1)
    {
        HGP_THIS_WINDOW->Layer[layer] = ((HGP_LAYER_INFO *)malloc(sizeof(HGP_LAYER_INFO)));
        HGP_THIS_WINDOW->Layer[layer]->lid[0] = HgWAddLayer(HGP_THIS_WINDOW->wid);
        HGP_THIS_WINDOW->Layer[layer]->lid[1] = HgWAddLayer(HGP_THIS_WINDOW->wid);

        for (int i = 0; i < HGP_RECT_CONTAINER_SIZE; i++)
        {
            HGP_THIS_OBJECT.RECT[i] = NULL;
        }
        for (int i = 0; i < HGP_CIRCLE_CONTAINER_SIZE; i++)
        {
            HGP_THIS_OBJECT.CIRCLE[i] = NULL;
        }
        for (int i = 0; i < HGP_ARC_CONTAINER_SIZE; i++)
        {
            HGP_THIS_OBJECT.ARC[i] = NULL;
        }
        for (int i = 0; i < HGP_FAN_CONTAINER_SIZE; i++)
        {
            HGP_THIS_OBJECT.FAN[i] = NULL;
        }

        for (int i = 0; i < HGP_OBJECT_TOTAL_NUM; i++)
        {
            HGP_THIS_OBJECT.table[i] = NULL;
        }
    }
    return layer;
}

void *hgp_add_object(int obj_type_flag, int window, int layer) //TODO:add obj
{
    switch (obj_type_flag)
    {
    case HGP_OBJECT_RECT_FLAG:
    {
        int rect_id = -1;
        for (int i = 0; i < HGP_RECT_CONTAINER_SIZE; i++)
        {
            if (HGP_THIS_OBJECT.RECT[i] == NULL)
            {
                rect_id = i;
                break;
            }
        }
        if (rect_id != -1)
        {
            HGP_THIS_LAYER->Object.RECT[rect_id] = malloc(sizeof(HGP_RECT));
            HGP_THIS_LAYER->Object.RECT[rect_id]->window_info.window_id = window;
            HGP_THIS_LAYER->Object.RECT[rect_id]->window_info.layer_id = layer;
            HGP_THIS_LAYER->Object.RECT[rect_id]->window_info.object_pointer_id = rect_id;
            for (int i = 0; i < HGP_OBJECT_TOTAL_NUM; i++)
            {
                if (HGP_THIS_OBJECT.table[i] == NULL)
                {
                    HGP_THIS_OBJECT.table[i] = malloc(sizeof(HGP_OBJECT_LOG));
                    HGP_THIS_OBJECT.table[i]->type = HGP_OBJECT_RECT_FLAG;
                    HGP_THIS_OBJECT.table[i]->pointer = rect_id;
                    HGP_THIS_OBJECT.RECT[rect_id]->window_info.table_id = i;
                    break;
                }
            }
            return (((void *)HGP_THIS_LAYER->Object.RECT[rect_id]));
        }
        else
        {
            //TODO:add warning
        }
        break;
    }

    case HGP_OBJECT_CIRCLE_FLAG:
    {
        int circle_id = -1;
        for (int i = 0; i < HGP_CIRCLE_CONTAINER_SIZE; i++)
        {
            if (HGP_THIS_OBJECT.CIRCLE[i] == NULL)
            {
                circle_id = i;
                break;
            }
        }
        if (circle_id != -1)
        {
            HGP_THIS_LAYER->Object.CIRCLE[circle_id] = malloc(sizeof(HGP_CIRCLE));
            HGP_THIS_LAYER->Object.CIRCLE[circle_id]->window_info.window_id = window;
            HGP_THIS_LAYER->Object.CIRCLE[circle_id]->window_info.layer_id = layer;
            HGP_THIS_LAYER->Object.CIRCLE[circle_id]->window_info.object_pointer_id = circle_id;
            for (int i = 0; i < HGP_OBJECT_TOTAL_NUM; i++)
            {
                if (HGP_THIS_OBJECT.table[i] == NULL)
                {
                    HGP_THIS_OBJECT.table[i] = malloc(sizeof(HGP_OBJECT_LOG));
                    HGP_THIS_OBJECT.table[i]->type = HGP_OBJECT_CIRCLE_FLAG;
                    HGP_THIS_OBJECT.table[i]->pointer = circle_id;
                    HGP_THIS_OBJECT.CIRCLE[circle_id]->window_info.table_id = i;
                    break;
                }
            }
            return (((void *)HGP_THIS_LAYER->Object.CIRCLE[circle_id]));
        }
        else
        {
            //TODO:add warning
        }
        break;
    }

    case HGP_OBJECT_ARC_FLAG:
    {
        int arc_id = -1;
        for (int i = 0; i < HGP_ARC_CONTAINER_SIZE; i++)
        {
            if (HGP_THIS_OBJECT.ARC[i] == NULL)
            {
                arc_id = i;
                break;
            }
        }
        if (arc_id != -1)
        {
            HGP_THIS_LAYER->Object.ARC[arc_id] = malloc(sizeof(HGP_ARC));
            HGP_THIS_LAYER->Object.ARC[arc_id]->window_info.window_id = window;
            HGP_THIS_LAYER->Object.ARC[arc_id]->window_info.layer_id = layer;
            HGP_THIS_LAYER->Object.ARC[arc_id]->window_info.object_pointer_id = arc_id;
            for (int i = 0; i < HGP_OBJECT_TOTAL_NUM; i++)
            {
                if (HGP_THIS_OBJECT.table[i] == NULL)
                {
                    HGP_THIS_OBJECT.table[i] = malloc(sizeof(HGP_OBJECT_LOG));
                    HGP_THIS_OBJECT.table[i]->type = HGP_OBJECT_ARC_FLAG;
                    HGP_THIS_OBJECT.table[i]->pointer = arc_id;
                    HGP_THIS_OBJECT.ARC[arc_id]->window_info.table_id = i;
                    break;
                }
            }
            return (((void *)HGP_THIS_LAYER->Object.ARC[arc_id]));
        }
        else
        {
            //TODO:add warning
        }
        break;
    }

    case HGP_OBJECT_FAN_FLAG:
    {
        int fan_id = -1;
        for (int i = 0; i < HGP_FAN_CONTAINER_SIZE; i++)
        {
            if (HGP_THIS_OBJECT.FAN[i] == NULL)
            {
                fan_id = i;
                break;
            }
        }
        if (fan_id != -1)
        {
            HGP_THIS_LAYER->Object.FAN[fan_id] = malloc(sizeof(HGP_FAN));
            HGP_THIS_LAYER->Object.FAN[fan_id]->window_info.window_id = window;
            HGP_THIS_LAYER->Object.FAN[fan_id]->window_info.layer_id = layer;
            HGP_THIS_LAYER->Object.FAN[fan_id]->window_info.object_pointer_id = fan_id;
            for (int i = 0; i < HGP_OBJECT_TOTAL_NUM; i++)
            {
                if (HGP_THIS_OBJECT.table[i] == NULL)
                {
                    HGP_THIS_OBJECT.table[i] = malloc(sizeof(HGP_OBJECT_LOG));
                    HGP_THIS_OBJECT.table[i]->type = HGP_OBJECT_FAN_FLAG;
                    HGP_THIS_OBJECT.table[i]->pointer = fan_id;
                    HGP_THIS_OBJECT.FAN[fan_id]->window_info.table_id = i;
                    break;
                }
            }
            return (((void *)HGP_THIS_LAYER->Object.FAN[fan_id]));
        }
        else
        {
            //TODO:add warning
        }
        break;
    }

    default:
        break;
    }
    return NULL;
}

int hgp_delete_object(int obj_type_flag, void *object) //TODO:obj
{
    switch (obj_type_flag)
    {
    case HGP_OBJECT_RECT_FLAG:
    {
        HGP_RECT *rectcache = (HGP_RECT *)object;
        int window = rectcache->window_info.window_id;
        int layer = rectcache->window_info.layer_id;
        int rect_id = rectcache->window_info.object_pointer_id;
        int table_id = rectcache->window_info.table_id;
        free(HGP_THIS_OBJECT.RECT[rect_id]);
        free(HGP_THIS_OBJECT.table[table_id]);
        HGP_THIS_OBJECT.table[table_id] = NULL;
        HGP_THIS_OBJECT.RECT[rect_id] = NULL;
        break;
    }
    case HGP_OBJECT_CIRCLE_FLAG:
    {
        HGP_CIRCLE *rectcache = (HGP_CIRCLE *)object;
        int window = rectcache->window_info.window_id;
        int layer = rectcache->window_info.layer_id;
        int circle_id = rectcache->window_info.object_pointer_id;
        int table_id = rectcache->window_info.table_id;
        free(HGP_THIS_OBJECT.CIRCLE[circle_id]);
        free(HGP_THIS_OBJECT.table[table_id]);
        HGP_THIS_OBJECT.table[table_id] = NULL;
        HGP_THIS_OBJECT.CIRCLE[circle_id] = NULL;
        break;
    }
    case HGP_OBJECT_ARC_FLAG:
    {
        HGP_ARC *rectcache = (HGP_ARC *)object;
        int window = rectcache->window_info.window_id;
        int layer = rectcache->window_info.layer_id;
        int arc_id = rectcache->window_info.object_pointer_id;
        int table_id = rectcache->window_info.table_id;
        free(HGP_THIS_OBJECT.ARC[arc_id]);
        free(HGP_THIS_OBJECT.table[table_id]);
        HGP_THIS_OBJECT.table[table_id] = NULL;
        HGP_THIS_OBJECT.ARC[arc_id] = NULL;
        break;
    }
    case HGP_OBJECT_FAN_FLAG:
    {
        HGP_FAN *rectcache = (HGP_FAN *)object;
        int window = rectcache->window_info.window_id;
        int layer = rectcache->window_info.layer_id;
        int fan_id = rectcache->window_info.object_pointer_id;
        int table_id = rectcache->window_info.table_id;
        free(HGP_THIS_OBJECT.FAN[fan_id]);
        free(HGP_THIS_OBJECT.table[table_id]);
        HGP_THIS_OBJECT.table[table_id] = NULL;
        HGP_THIS_OBJECT.FAN[fan_id] = NULL;
        break;
    }
    default:
        break;
    }
    return 1;
}

int hgp_delete_layer(int window, int layer) //TODO:obj
{
    for (int i = 0; i < HGP_RECT_CONTAINER_SIZE; i++)
    {
        free(HGP_THIS_OBJECT.RECT[i]);
        HGP_THIS_OBJECT.RECT[i] = NULL;
    }
    for (int i = 0; i < HGP_CIRCLE_CONTAINER_SIZE; i++)
    {
        free(HGP_THIS_OBJECT.CIRCLE[i]);
        HGP_THIS_OBJECT.CIRCLE[i] = NULL;
    }
    for (int i = 0; i < HGP_ARC_CONTAINER_SIZE; i++)
    {
        free(HGP_THIS_OBJECT.ARC[i]);
        HGP_THIS_OBJECT.ARC[i] = NULL;
    }
    for (int i = 0; i < HGP_FAN_CONTAINER_SIZE; i++)
    {
        free(HGP_THIS_OBJECT.FAN[i]);
        HGP_THIS_OBJECT.FAN[i] = NULL;
    }
    HgLRemove(HGP_THIS_LAYER->lid[0]);
    HgLRemove(HGP_THIS_LAYER->lid[1]);
    free(HGP_THIS_WINDOW->Layer[layer]);
    HGP_THIS_LAYER = NULL;
    return 1;
}

int hgp_destroy_window(int window, int quit_flag)
{
    for (int i = HG_MAX_LAYERS - 1; i >= 0; i--)
    {
        if (HGP_THIS_WINDOW->Layer[i] != NULL)
        {
            if (quit_flag == 1)
            {
                hgp_delete_layer(window, i);
            }
        }
    }
    HgWClose(HGP_THIS_WINDOW->wid);
    free(HGP_THIS_WINDOW);
    HGP_THIS_WINDOW = NULL;
    return 1;
}

void breakpoint()
{
    printf("breakpoint:%d\n", breakpointcount);
    breakpointcount++;
}

int hgp_update() //TODO:add obj
{
    for (int window = 0; window < HG_MAX_WINDOWS; window++)
    {
        if (HGP_THIS_WINDOW != NULL)
        {
            for (int layer = 0; layer < HG_MAX_LAYERS; layer++)
            {
                if (HGP_THIS_LAYER != NULL)
                {
                    for (int tablecount = 0; tablecount < HGP_OBJECT_TOTAL_NUM; tablecount++)
                    {
                        if (HGP_THIS_OBJECT.table[tablecount] != NULL)
                        {
                            int tmp_pointer = HGP_THIS_OBJECT.table[tablecount]->pointer;
                            switch (HGP_THIS_OBJECT.table[tablecount]->type)
                            {
                            case HGP_OBJECT_RECT_FLAG:
                            {
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.RECT[tmp_pointer]->fill_color, HG_ColorFill);
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.RECT[tmp_pointer]->shell_color, HG_ColorDraw);
                                HGCRectangle(HGP_THIS_LAYER->lid[layer_reverse_flag],
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->x,
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->y,
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->width / 2,
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->height / 2,
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->rotate_arc,
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->fill_color,
                                             HGP_THIS_OBJECT.RECT[tmp_pointer]->stroke_lenth);
                                break;
                            }
                            case HGP_OBJECT_CIRCLE_FLAG:
                            {
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->fill_color, HG_ColorFill);
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->shell_color, HG_ColorDraw);
                                HGCCircle(HGP_THIS_LAYER->lid[layer_reverse_flag],
                                          HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->x,
                                          HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->y,
                                          HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->r,
                                          HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->fill_flag,
                                          HGP_THIS_OBJECT.CIRCLE[tmp_pointer]->stroke_lenth);
                                break;
                            }
                            case HGP_OBJECT_ARC_FLAG:
                            {
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.ARC[tmp_pointer]->shell_color, HG_ColorDraw);
                                HGCFan(HGP_THIS_LAYER->lid[layer_reverse_flag],
                                       HGP_THIS_OBJECT.ARC[tmp_pointer]->x,
                                       HGP_THIS_OBJECT.ARC[tmp_pointer]->y,
                                       HGP_THIS_OBJECT.ARC[tmp_pointer]->r,
                                       HGP_THIS_OBJECT.ARC[tmp_pointer]->arc_start,
                                       HGP_THIS_OBJECT.ARC[tmp_pointer]->arc_start + HGP_THIS_OBJECT.ARC[tmp_pointer]->arc_value,
                                       0, 0);
                                break;
                            }
                            case HGP_OBJECT_FAN_FLAG:
                            {
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.FAN[tmp_pointer]->shell_color, HG_ColorDraw);
                                HGCSetColor(HGP_THIS_LAYER->lid[layer_reverse_flag], HGP_THIS_OBJECT.FAN[tmp_pointer]->fill_color, HG_ColorFill);
                                HGCFan(HGP_THIS_LAYER->lid[layer_reverse_flag],
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->x,
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->y,
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->r,
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->arc_start,
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->arc_start + HGP_THIS_OBJECT.FAN[tmp_pointer]->arc_value,
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->fill_flag,
                                       HGP_THIS_OBJECT.FAN[tmp_pointer]->stroke_lenth);
                                break;
                            }
                            default:
                                break;
                            }
                        }
                    }
                    if (layer_reverse_flag)
                    {
                        HgLShow(HGP_THIS_LAYER->lid[1], 1);
                        HgLShow(HGP_THIS_LAYER->lid[0], 0);
                        HgLClear(HGP_THIS_LAYER->lid[0]);
                    }
                    else
                    {
                        HgLShow(HGP_THIS_LAYER->lid[0], 1);
                        HgLShow(HGP_THIS_LAYER->lid[1], 0);
                        HgLClear(HGP_THIS_LAYER->lid[1]);
                    }
                }
            }
        }
    }
    if (layer_reverse_flag)
    {
        layer_reverse_flag = 0;
    }
    else
    {
        layer_reverse_flag = 1;
    }
    return 1;
}

int hgp_quit()
{
    for (int i = HG_MAX_WINDOWS - 1; i >= 0; i--)
    {
        if (HGP_WINDOW_CONTAINER[i] != NULL)
        {
            hgp_destroy_window(i, 0);
        }
        }
    hgp_killHG();
    return 1;
}

int hgp_killHG()
{
    FILE *hg_process_info = popen("ps -e | grep 'HgDisplayer' | awk '{print $1}'", "r");
    char pidbuf[10] = {0};
    fgets(pidbuf, 10, hg_process_info);
    int hgpid = 0;
    sscanf(pidbuf, "%d", &hgpid);
    if (hgpid != 0)
    {
        char hgkillcombuf[32] = {0};
        sprintf(hgkillcombuf, "kill -9 %d", hgpid);
        popen(hgkillcombuf, "w");
    }
    return hgpid;
}

int hgp_object_move(int type, void *ptr, double direct_arc, double distance) //TODO:add obj
{
    double move_x = cos(direct_arc) * distance;
    double move_y = sin(direct_arc) * distance;
    switch (type)
    {
    case HGP_OBJECT_RECT_FLAG:
    {
        HGP_RECT *rect = (HGP_RECT *)ptr;
        rect->x = rect->x + move_x;
        rect->y = rect->y + move_y;
        break;
    }
    case HGP_OBJECT_CIRCLE_FLAG:
    {
        HGP_CIRCLE *circle = (HGP_CIRCLE *)ptr;
        circle->x = circle->x + move_x;
        circle->y = circle->y + move_y;
        break;
    }
    case HGP_OBJECT_ARC_FLAG:
    {
        HGP_ARC *arc = (HGP_ARC *)ptr;
        arc->x = arc->x + move_x;
        arc->y = arc->y + move_y;
        break;
    }
    case HGP_OBJECT_FAN_FLAG:
    {
        HGP_FAN *fan = (HGP_FAN *)ptr;
        fan->x = fan->x + move_x;
        fan->y = fan->y + move_y;
        break;
    }
    }
    //hgp_update();
    return 0;
}

int hgp_object_zoom(int type, void *ptr, double zoom_rate, double zoom_center_x, double zoom_center_y) //TODO:add obj
{
    switch (type)
    {
    case HGP_OBJECT_RECT_FLAG:
    {
        HGP_RECT *rect = (HGP_RECT *)ptr;
        double center_x_cache = rect->x - (rect->width / 2) + (rect->width * zoom_center_x / 100);
        double center_y_cache = rect->y - (rect->height / 2) + (rect->height * zoom_center_y / 100);
        //turn
        rect->x = (rect->x - center_x_cache) * zoom_rate + center_x_cache;
        rect->y = (rect->y - center_y_cache) * zoom_rate + center_y_cache;
        rect->width = rect->width * zoom_rate;
        rect->height = rect->height * zoom_rate;
    }
    case HGP_OBJECT_CIRCLE_FLAG:
    {
        HGP_CIRCLE *circle = (HGP_CIRCLE *)ptr;
        double center_x_cache = circle->x - (circle->r / 2) + (circle->r * zoom_center_x / 100);
        double center_y_cache = circle->y - (circle->r / 2) + (circle->r * zoom_center_y / 100);
        //turn
        circle->x = (circle->x - center_x_cache) * zoom_rate + center_x_cache;
        circle->y = (circle->y - center_y_cache) * zoom_rate + center_y_cache;
        circle->r = circle->r * zoom_rate;
    }
    case HGP_OBJECT_ARC_FLAG:
    {
        HGP_ARC *arc = (HGP_ARC *)ptr;
        double center_x_cache = arc->x - (arc->r / 2) + (arc->r * zoom_center_x / 100);
        double center_y_cache = arc->y - (arc->r / 2) + (arc->r * zoom_center_y / 100);
        //turn
        arc->x = (arc->x - center_x_cache) * zoom_rate + center_x_cache;
        arc->y = (arc->y - center_y_cache) * zoom_rate + center_y_cache;
        arc->r = arc->r * zoom_rate;
    }
    case HGP_OBJECT_FAN_FLAG:
    {
        HGP_FAN *fan = (HGP_FAN *)ptr;
        double center_x_cache = fan->x - (fan->r / 2) + (fan->r * zoom_center_x / 100);
        double center_y_cache = fan->y - (fan->r / 2) + (fan->r * zoom_center_y / 100);
        //turn
        fan->x = (fan->x - center_x_cache) * zoom_rate + center_x_cache;
        fan->y = (fan->y - center_y_cache) * zoom_rate + center_y_cache;
        fan->r = fan->r * zoom_rate;
    }
    }
    return 0;
}

int hgp_object_rotate(int type, void *ptr, double rotate_arc, int need_angle_input_1) //TODO:add obj
{
    if (need_angle_input_1)
    {
        rotate_arc = rotate_arc * M_PI / 180;
        //printf("\nangle 2 arc:%lf\n",rotate_arc);
    }
    switch (type)
    {
    case HGP_OBJECT_RECT_FLAG:
    {
        HGP_RECT *rect = (HGP_RECT *)ptr;
        rect->rotate_arc = rect->rotate_arc + rotate_arc;
        if (rect->rotate_arc > 2 * M_PI)
            rect->rotate_arc = rect->rotate_arc - 2 * M_PI;
    }
    case HGP_OBJECT_ARC_FLAG:
    {
        HGP_ARC *arc = (HGP_ARC *)ptr;
        arc->arc_start = arc->arc_start + rotate_arc;
        if (arc->arc_start > 2 * M_PI)
            arc->arc_start = arc->arc_start - 2 * M_PI;
    }
    case HGP_OBJECT_FAN_FLAG:
    {
        HGP_FAN *fan = (HGP_FAN *)ptr;
        fan->arc_start = fan->arc_start + rotate_arc;
        if (fan->arc_start > 2 * M_PI)
            fan->arc_start = fan->arc_start - 2 * M_PI;
    }
    }
    return 0;
}

//-----Obj init-----//
HGP_RECT *hgp_rect_init(int window, int layer, double x, double y,
                        double width, double height,
                        unsigned long shell_color, unsigned long fill_color,
                        int fill_flag, double rotate_arc, int stroke_lenth)
{
    HGP_RECT *Operate_Rect_Pointer =
        ((HGP_RECT *)hgp_add_object(HGP_OBJECT_RECT_FLAG, window, layer));

    Operate_Rect_Pointer->x = x;
    Operate_Rect_Pointer->y = y;
    Operate_Rect_Pointer->width = width;
    Operate_Rect_Pointer->height = height;
    Operate_Rect_Pointer->shell_color = shell_color;
    Operate_Rect_Pointer->fill_color = fill_color;
    Operate_Rect_Pointer->fill_flag = fill_flag;
    Operate_Rect_Pointer->rotate_arc = rotate_arc;
    Operate_Rect_Pointer->stroke_lenth = stroke_lenth;
    return Operate_Rect_Pointer;
}

HGP_CIRCLE *hgp_circle_init(int window, int layer,
                            double x, double y, double r,
                            unsigned long shell_color,
                            unsigned long fill_color,
                            int fill_flag, int stroke_lenth)
{
    HGP_CIRCLE *Operate_Circle_Pointer =
        ((HGP_CIRCLE *)hgp_add_object(HGP_OBJECT_CIRCLE_FLAG, window, layer));

    Operate_Circle_Pointer->x = x;
    Operate_Circle_Pointer->y = y;
    Operate_Circle_Pointer->r = r;
    Operate_Circle_Pointer->shell_color = shell_color;
    Operate_Circle_Pointer->fill_color = fill_color;
    Operate_Circle_Pointer->fill_flag = fill_flag;
    Operate_Circle_Pointer->stroke_lenth = stroke_lenth;
    return Operate_Circle_Pointer;
}

HGP_ARC *hgp_arc_init(int window, int layer,
                      double x, double y, double r,
                      unsigned long shell_color,
                      double arc_start, double arc_value)
{
    HGP_ARC *Operate_Arc_Pointer =
        ((HGP_ARC *)hgp_add_object(HGP_OBJECT_ARC_FLAG, window, layer));

    Operate_Arc_Pointer->x = x;
    Operate_Arc_Pointer->y = y;
    Operate_Arc_Pointer->r = r;
    Operate_Arc_Pointer->shell_color = shell_color;
    Operate_Arc_Pointer->arc_start = arc_start;
    Operate_Arc_Pointer->arc_value = arc_value;
    return Operate_Arc_Pointer;
}

HGP_FAN *hgp_fan_init(int window, int layer,
                      double x, double y, double r,
                      unsigned long shell_color,
                      unsigned long fill_color,
                      int fill_flag, int stroke_lenth,
                      double arc_start, double arc_value)
{
    HGP_FAN *Operate_Fan_Pointer =
        ((HGP_FAN *)hgp_add_object(HGP_OBJECT_FAN_FLAG, window, layer));

    Operate_Fan_Pointer->x = x;
    Operate_Fan_Pointer->y = y;
    Operate_Fan_Pointer->r = r;
    Operate_Fan_Pointer->shell_color = shell_color;
    Operate_Fan_Pointer->fill_color = fill_color;
    Operate_Fan_Pointer->fill_flag = fill_flag;
    Operate_Fan_Pointer->stroke_lenth = stroke_lenth;
    Operate_Fan_Pointer->arc_start = arc_start;
    Operate_Fan_Pointer->arc_value = arc_value;
    return Operate_Fan_Pointer;
}