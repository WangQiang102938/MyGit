#include "handyplus.h"

int main()
{
    int wid = hgp_window_init(400, 410);
    HGP_RECT *rect[10][10] = {NULL};
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
        rect[i][j] = hgp_rect_init(wid, 0, i * 40 + 20, j * 40 + 20, 40, 40,HG_WHITE, HG_WHITE, 1, 0, 0);
        }
    }
    HGP_RECT *exitrect = hgp_rect_init(wid, 0, 200, 405, 400, 10, HG_RED, HG_RED, 1, 0, 1);
    hgp_update();
    hgevent *event = NULL;
    HgWSetEventMask(HGP_WINDOW_CONTAINER[wid]->wid, HG_MOUSE_DOWN);
    while (1)
    {
        hgp_update();
        event = HgEvent();
        if (event != NULL)
        {
            int x = event->x / 40;
            int y = event->y / 40;
            if (rect[x][y]->fill_color == HG_WHITE)
            {
                rect[x][y]->fill_color = 0x000001;//Only HG_BLACK CANNOT USE, Maybe inner calculate have this:?*HG_BLACK......(anything time 0 equal 0)
            }
            else
            {
                rect[x][y]->fill_color = HG_WHITE;
            }
            hgp_update();
            if (event->y > 400)
            {
                break;
            }
        }
    }
    hgp_quit();
}