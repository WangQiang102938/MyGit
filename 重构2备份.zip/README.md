# MyGit
Self training
