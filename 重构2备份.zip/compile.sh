echo ________________________________________________________________________________________________________________________________________________________________________________________________
hgcc handyplus.c test.c -g -o test.out
hgcc handyplus.c 1.c -g -o 1.out
hgcc handyplus.c 2.c -g -o 2.out
hgcc handyplus.c 3.c -g -o 3.out
hgcc handyplus.c test2.c -g -o test2.out


